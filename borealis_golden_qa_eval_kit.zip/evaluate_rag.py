"""
Borealis Graph-Compiled RAG Golden QA Loader & Deterministic Judge (`evaluate_rag.py`)
--------------------------------------------------------------------------------------
Loads `borealis_golden_qa.json` and exposes `judge_ground_truth(y, y_hat)` to deterministically
score a RAG/Graph pipeline prediction (`y_hat`) against the ground-truth contract (`y`).

Why a Deterministic Symbolic Judge Beats "LLM-as-a-Judge" for Engineering Specs:
  1. Positive SKU Recall: Did `y_hat` select every required part SKU (`required_skus`)?
  2. Negative Prohibition Safety Gate: Did `y_hat` accidentally recommend a prohibited baseline
     SKU (`prohibited_skus`) without flagging it as prohibited/replaced? (Instant safety fail if violated).
  3. Multi-Hop Provenance Recall: Did the retrieval trace include the required overriding clauses?

Supports `y_hat` passed EITHER as:
  - A structured dict (`{"selected_skus": [...], "prohibited_skus": [...], "retrieved_clauses": [...], "answer_text": "..."}`)
  - Or a raw natural-language string (the judge automatically parses recommended vs. prohibited SKUs and clauses).
"""

import json
import re
from pathlib import Path
from typing import Dict, Any, List, Union, Tuple


SKU_PATTERN = re.compile(r"\b(?:PIPE-HDPE11-STD|PIPE-PEX9-ARC|VLV-200-SS|VLV-200-LT|SEAL-VT-09|SEAL-FVMQ-40|SEAL-FFKM-ULT90|BOLT-B7-2H|BOLT-L7-L4|ACT-PN-100|ACT-HYD-350|DS-04)\b")
CLAUSE_PATTERN = re.compile(r"(?:SEC-|Section\s+)([1-5]\.[1-9])", re.IGNORECASE)
NEGATION_CUE_PATTERN = re.compile(
    r"\b(prohibit(?:ed|s)?|cannot|do\s+not|not\s+approved|replace(?:d|s)?|supersede(?:d|s)?|override(?:n|s)?|stall(?:s)?|fail(?:s|ure)?|instead\s+of|upgrade\s+from| embrittlement|swell)\b",
    re.IGNORECASE,
)


def load_golden_qa(json_path: Union[str, Path] = "borealis_golden_qa.json") -> List[Dict[str, Any]]:
    """Loads the Borealis Golden QA dataset items from disk."""
    path = Path(json_path)
    if not path.exists():
        # Check starter/ or parent fallback paths
        for candidate in [Path("starter") / path.name, Path(__file__).parent / path.name]:
            if candidate.exists():
                path = candidate
                break
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data["items"]


def parse_unstructured_prediction(text: str) -> Dict[str, List[str]]:
    """
    If `y_hat` is a raw LLM response string rather than a structured dict, splits text into
    clauses/sentences to distinguish recommended SKUs from SKUs mentioned only as prohibited/replaced.
    """
    clauses = re.split(r"[.;\n]|\b(?:however|whereas|while|unless|but)\b", text, flags=re.IGNORECASE)
    selected_skus = set()
    negated_skus = set()

    for span in clauses:
        skus_in_span = SKU_PATTERN.findall(span)
        if not skus_in_span:
            continue
        if NEGATION_CUE_PATTERN.search(span):
            for sku in skus_in_span:
                negated_skus.add(sku)
        else:
            for sku in skus_in_span:
                selected_skus.add(sku)

    # Any SKU that was explicitly selected in an affirmative clause (and never negated) counts as selected
    final_selected = sorted(list(selected_skus - negated_skus))
    # Fallback: if a sentence contained both a negation cue ("replaces #BOLT-B7-2H with #BOLT-L7-L4"),
    # handle "with/upgrade to/mandates <SKU>" as positive selection
    positive_override_matches = re.findall(
        r"(?:upgrade\s+to|replace[^#]+with|mandates?|requires?|substitute|approved[^#]+is|use)\s+[^#]*?#?("
        + "|".join([
            "PIPE-HDPE11-STD", "PIPE-PEX9-ARC", "VLV-200-SS", "VLV-200-LT",
            "SEAL-VT-09", "SEAL-FVMQ-40", "SEAL-FFKM-ULT90", "BOLT-B7-2H",
            "BOLT-L7-L4", "ACT-PN-100", "ACT-HYD-350", "DS-04"
        ])
        + r")",
        text,
        flags=re.IGNORECASE,
    )
    for sku in positive_override_matches:
        sku_up = sku.upper()
        if sku_up not in final_selected:
            final_selected.append(sku_up)
        if sku_up in negated_skus:
            negated_skus.remove(sku_up)

    retrieved_clauses = sorted(list({f"SEC-{m}" for m in CLAUSE_PATTERN.findall(text)}))
    return {
        "selected_skus": sorted(final_selected),
        "prohibited_skus_flagged": sorted(list(negated_skus)),
        "retrieved_clauses": retrieved_clauses,
    }


def judge_ground_truth(
    y: Dict[str, Any],
    y_hat: Union[str, Dict[str, Any]],
    strict_clause_provenance: bool = False,
) -> Dict[str, Any]:
    """
    Deterministic Ground-Truth Judge: compares `y` (ground_truth dict or full QA item)
    against `y_hat` (model prediction dict or raw response string).

    Parameters:
      - y: Ground-truth dictionary (either `item["ground_truth"]` or the full QA `item`).
      - y_hat: Model prediction, either as a structured dict:
          {
            "selected_skus": ["VLV-200-LT", "SEAL-FFKM-ULT90", ...],
            "retrieved_clauses": ["SEC-4.5", "SEC-5.2", ...],
            "answer_text": "..."
          }
          OR a raw natural-language answer string.
      - strict_clause_provenance: If True, requires >= 75% recall on `required_clauses` in addition
          to 100% exact SKU compliance.

    Returns:
      Dict containing:
        - `success` (bool): True ONLY if all required SKUs are present, ZERO prohibited SKUs are
          falsely recommended, and required numeric/clause checks pass.
        - `score` (float): Composite score in [0.0, 1.0].
        - `metrics` (dict): Granular breakdown (sku_recall, safety_violation_count, clause_recall, etc.)
        - `failure_reasons` (list[str]): Exact human-readable diagnostic reasons if `success == False`.
    """
    gt = y.get("ground_truth", y)
    required_skus = {s.replace("PART:", "").upper() for s in gt.get("required_skus", [])}
    prohibited_skus = {s.replace("PART:", "").upper() for s in gt.get("prohibited_skus", [])}
    required_clauses = {c.upper() for c in gt.get("required_clauses", [])}
    required_numeric = gt.get("required_numeric_facts", [])

    # Normalize y_hat
    if isinstance(y_hat, str):
        parsed = parse_unstructured_prediction(y_hat)
        pred_selected_skus = {s.replace("PART:", "").upper() for s in parsed["selected_skus"]}
        pred_clauses = {c.upper() for c in parsed["retrieved_clauses"]}
        answer_text = y_hat
    elif isinstance(y_hat, dict):
        raw_text = y_hat.get("answer_text", "") or ""
        parsed_from_text = parse_unstructured_prediction(raw_text) if raw_text else {
            "selected_skus": [], "retrieved_clauses": []
        }
        explicit_skus = {s.replace("PART:", "").upper() for s in y_hat.get("selected_skus", [])}
        explicit_clauses = {c.upper() for c in y_hat.get("retrieved_clauses", [])}
        pred_selected_skus = explicit_skus if explicit_skus else set(parsed_from_text["selected_skus"])
        pred_clauses = explicit_clauses | set(parsed_from_text["retrieved_clauses"])
        answer_text = raw_text
    else:
        raise TypeError("y_hat must be a raw string or a structured dictionary.")

    # 1. Positive SKU Recall
    matched_required_skus = required_skus & pred_selected_skus
    missing_required_skus = sorted(list(required_skus - pred_selected_skus))
    sku_recall = (len(matched_required_skus) / len(required_skus)) if required_skus else 1.0

    # 2. Negative Prohibition Check (Critical Safety Gate)
    # Any SKU in `prohibited_skus` that appears in `pred_selected_skus` is a fatal override miss
    illegally_selected_prohibited = sorted(list(prohibited_skus & pred_selected_skus))
    safety_pass = len(illegally_selected_prohibited) == 0

    # 3. Provenance / Clause Recall
    matched_clauses = required_clauses & pred_clauses
    missing_clauses = sorted(list(required_clauses - pred_clauses))
    clause_recall = (len(matched_clauses) / len(required_clauses)) if required_clauses else 1.0

    # 4. Numeric Fact Verification (when applicable)
    missing_numeric = [
        fact for fact in required_numeric
        if fact.lower() not in answer_text.lower()
    ] if answer_text and required_numeric else []

    # Build Failure Diagnostics
    failure_reasons: List[str] = []
    if missing_required_skus:
        failure_reasons.append(f"Missing required overridden SKU(s): {missing_required_skus}")
    if not safety_pass:
        failure_reasons.append(
            f"SAFETY VIOLATION: Recommended prohibited baseline/incompatible SKU(s): {illegally_selected_prohibited}"
        )
    if missing_numeric:
        failure_reasons.append(f"Missing required numeric engineering fact(s): {missing_numeric}")
    if strict_clause_provenance and clause_recall < 0.75:
        failure_reasons.append(
            f"Insufficient clause provenance recall ({clause_recall:.0%} < 75%). Missing: {missing_clauses}"
        )
    elif not required_skus and clause_recall < 1.0:
        # For pure policy/precedence questions (like QA-07) with no SKUs, require clause citation
        failure_reasons.append(f"Missing required governing clause citation(s): {missing_clauses}")

    success = len(failure_reasons) == 0

    # Composite continuous score: 60% SKU recall + 20% Clause Provenance + 20% Safety Gate (zeroed if safety fails)
    raw_score = (0.75 * sku_recall + 0.25 * clause_recall) if required_skus else clause_recall
    final_score = round(raw_score if safety_pass else raw_score * 0.25, 4)

    return {
        "success": success,
        "score": final_score,
        "metrics": {
            "sku_recall": round(sku_recall, 4),
            "clause_recall": round(clause_recall, 4),
            "safety_pass": safety_pass,
            "matched_skus": sorted(list(matched_required_skus)),
            "missing_skus": missing_required_skus,
            "prohibited_sku_violations": illegally_selected_prohibited,
            "matched_clauses": sorted(list(matched_clauses)),
            "missing_clauses": missing_clauses,
        },
        "failure_reasons": failure_reasons,
    }


if __name__ == "__main__":
    qa_items = load_golden_qa()
    q1 = qa_items[0]

    print(f"Loaded {len(qa_items)} Golden QA items. Running self-test on {q1['id']} ({q1['category']})...\n")

    # Simulation A: Naive Top-3 Vector RAG output (returns Section 2.0 baseline SKUs)
    naive_vector_rag_y_hat = {
        "selected_skus": ["PIPE-HDPE11-STD", "VLV-200-SS", "SEAL-VT-09", "BOLT-B7-2H", "ACT-PN-100"],
        "retrieved_clauses": ["SEC-2.1", "SEC-2.2", "SEC-2.3"],
        "answer_text": (
            "Based on Section 2.1, 2.2, and 2.3, Manifold Loop B at 120 PSI uses PIPE-HDPE11-STD piping, "
            "VLV-200-SS isolation valve, SEAL-VT-09 Viton seals, BOLT-B7-2H bolts, and ACT-PN-100 actuator."
        ),
    }

    # Simulation B: Graph-Compiled CTE output (walks Tiers 1 -> 2 -> 3)
    graph_cte_y_hat = {
        "selected_skus": ["PIPE-PEX9-ARC", "VLV-200-LT", "SEAL-FFKM-ULT90", "BOLT-L7-L4", "ACT-HYD-350"],
        "retrieved_clauses": [
            "SEC-1.2", "SEC-2.2", "SEC-3.2", "SEC-3.3",
            "SEC-4.1", "SEC-4.2", "SEC-4.3", "SEC-4.5", "SEC-5.2"
        ],
        "answer_text": q1["expected_answer"],
    }

    res_naive = judge_ground_truth(q1, naive_vector_rag_y_hat)
    res_graph = judge_ground_truth(q1, graph_cte_y_hat)

    print("=== 1. Naive Top-3 Vector RAG Verdict ===")
    print(json.dumps(res_naive, indent=2))

    print("\n=== 2. Graph-Compiled CTE Verdict ===")
    print(json.dumps(res_graph, indent=2))
